./main.sh -u
./main.sh -s
./main.sh -x > routine.xml
