/usr/share/loadshedding/main.sh -u
/usr/share/loadshedding/main.sh -x > /usr/share/loadshedding/routine.xml
