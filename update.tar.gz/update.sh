/usr/share/loadshedding/main.sh -u
/usr/share/loadshedding/main.sh -s
/usr/share/loadshedding/main.sh -x > routine.xml
